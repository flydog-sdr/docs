# customised-scripts

Customised script for FlyDog SDR upgrading process.
